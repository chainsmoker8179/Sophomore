import sys
from PyQt5.QtWidgets import (
    QApplication, QVBoxLayout, QLabel, QLineEdit, QToolButton, QGroupBox, QMessageBox)
from PyQt5.QtCore import pyqtSignal
from PyQt5.QtGui import QIcon

KEY_LIST = ['id', 'name', 'location', 'capacity', 'open_time', 'close_time']


class VenueInfo(QGroupBox):
    '''
    编辑场馆信息的界面
    返回venue_msg{
        'id': str,
        'name': str,
        'location': str,
        'capacity': int,
        'open_time': time,
        'close_time': time
    }
    '''
    after_close = pyqtSignal(dict)

    def __init__(self, venue_msg: dict = None):
        super().__init__()
        if venue_msg is not None:
            self.venue_msg = venue_msg
        else:
            self.venue_msg = {
                'id': '请输入场馆号',
                'name': '请输入场馆名',
                'location': '请输入场馆地点',
                'capacity': '请输入场馆容量',
                'open_time': '请输入场馆开放时间',
                'close_time': '请输入场馆闭馆时间',
            }

        self.title = QLabel()
        self.title.setText('场馆信息')

        self.subTitle = QLabel()
        self.subTitle.setText('编辑场馆信息')

        # 场馆号输入框
        self.idInput = QLineEdit()
        self.idInput.setFixedSize(400, 40)
        self.idInput.setText(self.venue_msg['id'])
        self.idInput.initText = '请输入场馆号'
        self.idInput.mousePressEvent = lambda x: self.inputClick(self.idInput)
        # id不允许修改
        if self.idInput.text() != self.idInput.initText:
            self.idInput.setEnabled(False)

        # 场馆名输入框
        self.nameInput = QLineEdit()
        self.nameInput.setFixedSize(400, 40)
        self.nameInput.setText(self.venue_msg['name'])
        self.nameInput.initText = '请输入场馆名'
        self.nameInput.mousePressEvent = lambda x: self.inputClick(self.nameInput)

        # 场馆位置输入框
        self.lcInput = QLineEdit()
        self.lcInput.setFixedSize(400, 40)
        self.lcInput.setText(str(self.venue_msg['location']))
        self.lcInput.initText = '请输入场馆位置'
        self.lcInput.mousePressEvent = lambda x: self.inputClick(self.lcInput)

        # 容量
        self.cpInput = QLineEdit()
        self.cpInput.setFixedSize(400, 40)
        self.cpInput.setText(str(self.venue_msg['capacity']))
        self.cpInput.initText = '请输入场馆容量'
        self.cpInput.mousePressEvent = lambda x: self.inputClick(self.cpInput)

        # 场馆开放时间
        self.openInput = QLineEdit()
        self.openInput.setFixedSize(400, 40)
        self.openInput.setText(self.venue_msg['open_time'])
        self.openInput.initText = '请输入场馆开放时间'
        self.openInput.mousePressEvent = lambda x: self.inputClick(self.openInput)

        # 场馆闭馆时间
        self.closeInput = QLineEdit()
        self.closeInput.setFixedSize(400, 40)
        self.closeInput.setText(self.venue_msg['close_time'])
        self.closeInput.initText = '请输入场馆闭馆时间'
        self.closeInput.mousePressEvent = lambda x: self.inputClick(self.closeInput)

        # 提交
        self.submit = QToolButton()
        self.submit.setText('提交')
        self.submit.setFixedSize(400, 40)
        self.submit.clicked.connect(self.submitFunction)

        # 退出
        self.back = QToolButton()
        self.back.setText('退出')
        self.back.setFixedSize(400, 40)
        self.back.clicked.connect(self.close)

        self.btnList = [
            self.idInput,
            self.nameInput,
            self.lcInput,
            self.cpInput,
            self.openInput,
            self.closeInput
        ]

        self.bodyLayout = QVBoxLayout()
        self.bodyLayout.addWidget(self.title)
        self.bodyLayout.addWidget(self.subTitle)
        for i in self.btnList:
            self.bodyLayout.addWidget(i)
        self.bodyLayout.addWidget(self.submit)
        self.bodyLayout.addWidget(self.back)

        self.setLayout(self.bodyLayout)
        self.initUI()

    def inputClick(self, e):
        for item in self.btnList:
            if item.text() == '':
                item.setText(item.initText)
        if e.text() == e.initText:
            e.setText('')

    def submitFunction(self):
        for btn, key in zip(self.btnList, KEY_LIST):
            if btn.text() == btn.initText:
                self.venue_msg[key] = ''
            else:
                self.venue_msg[key] = btn.text()

        if len(self.venue_msg['name']) == 0:
            self.errorBox('场馆名不能为空')
            return
        if len(self.venue_msg['location']) == 0:
            self.errorBox('场馆位置不能为空')
            return
        try:
            self.venue_msg['capacity'] = int(self.venue_msg['capacity'])
        except ValueError:
            self.errorBox('场馆容量必须是整数')
            return
        self.close()
        self.after_close.emit(self.venue_msg)

    def initUI(self):
        self.setFixedSize(422, 550)
        self.setWindowTitle('编辑场馆信息')
        # self.setWindowIcon(QIcon('icon/book.png'))
        self.setMyStyle()

    def errorBox(self, mes: str):
        msgBox = QMessageBox(
            QMessageBox.Warning,
            "警告!",
            mes,
            QMessageBox.NoButton,
            self
        )
        msgBox.addButton("确认", QMessageBox.AcceptRole)
        msgBox.exec_()

    def setMyStyle(self):
        self.setStyleSheet('''
        QWidget{
            background-color: white;
        }
        QLineEdit{
            border:0px;
            border-bottom: 1px solid rgba(229, 229, 229, 1);
            color: grey;
        }
        QToolButton{
            border: 0px;
            background-color:rgba(52, 118, 176, 1);
            color: white;
            font-size: 25px;
            font-family: 微软雅黑;
        }
        QGroupBox{
            border: 1px solid rgba(229, 229, 229, 1);
            border-radius: 5px;
        }
        ''')
        self.title.setStyleSheet('''
        *{
            color: rgba(113, 118, 121, 1);
            font-size: 30px;
            font-family: 微软雅黑;
        }
        ''')
        self.subTitle.setStyleSheet('''
        *{
            color: rgba(184, 184, 184, 1);
        }
        ''')


if __name__ == '__main__':
    venue_msg = {
        'id': '1',
        'name': '宋卿体育馆',
        'location': '桂园操场',
        'capacity': 100,
        'open_time': '07:00:00',
        'close_time': '21:00:00'
    }
    app = QApplication(sys.argv)
    ex = VenueInfo(venue_msg)
    ex.show()
    sys.exit(app.exec_())
