import hashlib

import pymysql
import os
import subprocess



CONFIG = {
    "host": '127.0.0.1',
    "user": 'root',
    "pwd": 'fen386838',
    'db': 'venue'
}
def signin(user_message: dict) -> dict:
    """
    用户或管理员登录
    :param user_message: 包含ID和PASSWORD的字典
    :return: 用户或管理员信息字典
    """
    ans = None
    try:
        conn = pymysql.connect(host=CONFIG['host'], user=CONFIG['user'], password=CONFIG['pwd'], database=CONFIG['db'])
        cursor = conn.cursor()
        cursor.execute('''
        SELECT id
        FROM administrator
        WHERE id=%s AND password=%s
        ''', (
            user_message['ID'],
            user_message['PASSWORD']
        ))
        temp = cursor.fetchall()
        if len(temp) == 0:
            cursor.execute('''
            SELECT id, name, email, phone
            FROM users
            WHERE id=%s AND password=%s
            ''', (
                user_message['ID'],
                user_message['PASSWORD']
            ))
            temp = cursor.fetchall()
            if len(temp) > 0:
                ans = {
                    'id': temp[0][0],
                    'name': temp[0][1],
                    'email': temp[0][2],
                    'phone': temp[0][3],
                    'class': 'user'
                }
        else:
            ans = {
                'id': temp[0][0],
                'class': 'admin'
            }
        conn.commit()
    except Exception as e:
        print('Signin error!')
        print(e)
    finally:
        if conn:
            conn.close()
        return ans

def remove_blank(val):
    """
    去掉字符串末尾的空格
    :param val: 字符串
    :return: 去掉末尾空格的字符串
    """
    if type(val) is not str:
        return val
    return val.rstrip()

def convert(val: list) -> dict:
    """
    将元组列表转换为字典
    :param val: 元组列表
    :return: 字典
    """
    if not val:
        return None
    val = val[0]
    if len(val) == 4:
        return {
            'class': 'users',
            'id': remove_blank(val[0]),
            'name': remove_blank(val[1]),
            'email': remove_blank(val[2]),
            'phone': remove_blank(val[3])
        }
    else:
        return {
            'class': 'admin',
            'id': remove_blank(val[0])
        }


def encrypt(val):
    """
    对密码进行加密
    :param val: 密码
    :return: 加密后的密码
    """
    h = hashlib.sha256()
    h.update(val.encode('UTF-8'))
    return h.hexdigest()

def check_user_info(info: dict) -> dict:
    """
    检查注册信息
    :param info: 包含用户信息的字典
    :return: 检查结果字典
    """
    ans = {
        'res': 'fail',
        'reason': ''
    }
    if len(info['id']) > 15:
        ans['reason'] = 'ID长度超过15'
        return ans
    if not info['id'].isalnum():
        ans['reason'] = 'ID存在非法字符'
        return ans
    if info['password'] != info['repassword']:
        ans['reason'] = '两次输入密码不一致'
        return ans
    ans['res'] = 'success'
    return ans

def signup(user_message: dict) -> bool:
    """
    用户注册
    :param user_message: 包含用户信息的字典
    :return: 注册结果布尔值
    """
    res = True
    try:
        conn = pymysql.connect(host=CONFIG['host'], user=CONFIG['user'], password=CONFIG['pwd'], database=CONFIG['db'])
        cursor = conn.cursor()
        cursor.execute('''
            SELECT *
            FROM users
            WHERE id=%s
            ''', (user_message['id']))
        if len(cursor.fetchall()) != 0:
            raise Exception('用户已存在!')
        cursor.execute('''
        INSERT
        INTO users (id, password, name, email, phone)
        VALUES(%s, %s, %s, %s, %s)
        ''', (
            user_message['id'],
            user_message['password'],
            user_message['name'],
            user_message['email'],
            user_message['phone']
        ))
        conn.commit()
    except Exception as e:
        print('Signup error!')
        print(e)
        res = False
    finally:
        if conn:
            conn.close()
        return res

def update_users(user_message: dict) -> bool:
    """
    更新用户信息
    :param user_message: 包含用户信息的字典
    :return: 更新结果布尔值
    """
    try:
        res = True
        conn = pymysql.connect(host=CONFIG['host'], user=CONFIG['user'], password=CONFIG['pwd'], database=CONFIG['db'])
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE users
            SET name=%s, email=%s, phone=%s
            WHERE id=%s
            ''', (
                user_message['name'],
                user_message['email'],
                user_message['phone'],
                user_message['id']
            ))
        if 'password' in user_message:
            cursor.execute('''
            UPDATE users
            SET password=%s
            WHERE id=%s
            ''', (
                user_message['password'],
                user_message['id']
            ))
        conn.commit()
    except Exception as e:
        print('Update error!')
        print(e)
        res = False
    finally:
        if conn:
            conn.close()
        return res

def get_users_info(id: str) -> dict:
    """
    获取用户信息
    :param id: 用户ID
    :return: 用户信息字典
    """
    try:
        conn = pymysql.connect(host=CONFIG['host'], user=CONFIG['user'], password=CONFIG['pwd'], database=CONFIG['db'])
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, name, email, phone
            FROM users
            WHERE id=%s
            ''', (id,))
        ans = cursor.fetchall()
    except Exception as e:
        print(e)
        print('get users info error')
    finally:
        if conn:
            conn.close()
        return convert(ans)


from datetime import datetime, timedelta


def get_booking_history(searchVal: str) -> list:
    """
    获取用户的历史预约信息或场馆的预约记录
    :param searchVal: 用户ID或场馆ID
    :return: 预约信息列表
    """
    try:
        conn = pymysql.connect(host=CONFIG['host'], user=CONFIG['user'], password=CONFIG['pwd'], database=CONFIG['db'])
        cursor = conn.cursor()

        if searchVal:
            cursor.execute('''
                SELECT bookings.id, user_id, venue_id, venues.name, 
                       booking_date, 
                       start_time, 
                       end_time, 
                       status
                FROM bookings
                JOIN venues ON bookings.venue_id = venues.id
                WHERE user_id=%s OR venue_id=%s
            ''', (searchVal, searchVal))
        else:
            cursor.execute('''
                SELECT bookings.id, user_id, venue_id, venues.name, 
                       booking_date, 
                       start_time, 
                       end_time, 
                       status
                FROM bookings
                JOIN venues ON bookings.venue_id = venues.id
            ''')

        res = cursor.fetchall()

        # 获取当前日期和时间
        current_date = datetime.now().date()
        current_time = datetime.now().time()

        result = []
        for row in res:
            # 转换timedelta对象为日期和时间对象
            booking_date = (datetime(1, 1, 1) + row[4]).date() if isinstance(row[4], timedelta) else row[4]
            start_time = (datetime.min + row[5]).time() if isinstance(row[5], timedelta) else row[5]
            end_time = (datetime.min + row[6]).time() if isinstance(row[6], timedelta) else row[6]

            # 判断是否已过期
            if booking_date < current_date or (booking_date == current_date and end_time < current_time):
                status = '已结束'
            else:
                status = '取消'

            # 构建结果行，去除末尾空格
            result_row = (
                row[0],  # 预约ID
                remove_blank(row[1]),
                remove_blank(row[2]),
                remove_blank(row[3]),
                booking_date.strftime('%Y-%m-%d'),
                start_time.strftime('%H:%M'),
                end_time.strftime('%H:%M'),
                status
            )
            result.append(result_row)

    except Exception as e:
        print('get_booking_history error!')
        print(e)
        result = []
    finally:
        if conn:
            conn.close()
        return result


def search_users(info: str) -> list:
    """
    查找用户
    :param info: 用户ID或姓名
    :return: 用户信息列表
    """

    res = []
    try:
        val = [(info, f'%{info}%')]
        conn = pymysql.connect(host=CONFIG['host'], user=CONFIG['user'], password=CONFIG['pwd'], database=CONFIG['db'])
        cursor = conn.cursor()
        # 显示所有用户信息
        if info == 'ID/姓名' or info == '':
            cursor.execute('''
            SELECT id, name, email, phone
            FROM users
            ''')
            res += cursor.fetchall()
        else:
            # 按条件查找
            for i in val:
                cursor.execute('''
                SELECT id, name, email, phone
                FROM users
                WHERE id=%s OR name LIKE %s
                ''', i)
                res += cursor.fetchall()
        res = list(set(res))
        temp = [tuple(map(remove_blank, i)) for i in res]
        res = temp
    except Exception as e:
        print('Search users error!')
        print(e)
        res = []
    finally:
        if conn:
            conn.close()
        return res


def delete_users(uid: str) -> bool:
    """
    删除用户信息以及用户的预约记录
    :param uid: 用户ID
    :return: 删除结果布尔值
    """
    try:
        res = True
        conn = pymysql.connect(host=CONFIG['host'], user=CONFIG['user'], password=CONFIG['pwd'], database=CONFIG['db'])
        cursor = conn.cursor()

        # 删除用户的预约记录
        cursor.execute('''
            DELETE FROM bookings
            WHERE user_id = %s
        ''', (uid,))

        # 删除用户信息
        cursor.execute('''
            DELETE FROM users
            WHERE id = %s
        ''', (uid,))

        conn.commit()
    except Exception as e:
        print('delete error!')
        print(e)
        res = False
    finally:
        if conn:
            conn.close()
        return res


def get_venue_info(search_value: str = '') -> list:
    """
    获取场馆信息
    :param search_value: 搜索值
    :return: 场馆信息列表
    """
    try:
        conn = pymysql.connect(host=CONFIG['host'], user=CONFIG['user'], password=CONFIG['pwd'], database=CONFIG['db'])
        cursor = conn.cursor()

        query = '''
            SELECT id, name, location, capacity, open_time, close_time
            FROM venues
            WHERE 1=1
        '''
        params = []

        if search_value:
            query += '''
                AND (id LIKE %s
                OR name LIKE %s
                OR location LIKE %s)
            '''
            params.extend([f'%{search_value}%', f'%{search_value}%', f'%{search_value}%'])

        cursor.execute(query, params)
        res = cursor.fetchall()

        # Ensure the result is a list of strings
        result = [tuple(map(remove_blank, i)) for i in res]
    except Exception as e:
        print('Get venue info error!')
        print(e)
        result = []
    finally:
        if conn:
            conn.close()

    return result



def new_venue(venue_info: dict) -> bool:
    """
    添加新场馆
    :param venue_info: 场馆信息字典
    :return: 添加结果布尔值
    """
    res = True
    try:
        conn = pymysql.connect(host=CONFIG['host'], user=CONFIG['user'], password=CONFIG['pwd'], database=CONFIG['db'])
        cursor = conn.cursor()
        cursor.execute('''
            SELECT *
            FROM venues
            WHERE id=%s
            ''', (venue_info['id']))
        if len(cursor.fetchall()) != 0:
            raise Exception('场馆ID已存在!')
        # 插入新场馆
        cursor.execute('''
                INSERT INTO venues (id, name, location, capacity, open_time, close_time)
                VALUES(%s, %s, %s, %s, %s, %s)
                ''', (
            venue_info['id'],
            venue_info['name'],
            venue_info['location'],
            venue_info['capacity'],
            venue_info['open_time'],
            venue_info['close_time']
        ))

        conn.commit()
    except Exception as e:
        print('add error!')
        print(e)
        res = False
    finally:
        if conn:
            conn.close()
        return res

def update_venue(venue_info: dict) -> bool:
    """
    更新场馆信息
    :param venue_info: 场馆信息字典
    :return: 更新结果布尔值
    """
    try:
        res = True
        conn = pymysql.connect(host=CONFIG['host'], user=CONFIG['user'], password=CONFIG['pwd'], database=CONFIG['db'])
        cursor = conn.cursor()
        # 更新venue表
        cursor.execute('''
            UPDATE venues
            SET name=%s, location=%s, capacity=%s, open_time=%s, close_time=%s
            WHERE id=%s
            ''', (
            venue_info['name'],
            venue_info['location'],
            venue_info['capacity'],
            venue_info['open_time'],
            venue_info['close_time'],
            venue_info['id']
        ))

        conn.commit()
    except Exception as e:
        print('Update error!')
        print(e)
        res = False
    finally:
        if conn:
            conn.close()
        return res

def delete_venue(id: str) -> bool:
    """
    删除场馆
    :param id: 场馆ID
    :return: 删除结果布尔值
    """
    try:
        res = True
        conn = pymysql.connect(host=CONFIG['host'], user=CONFIG['user'], password=CONFIG['pwd'], database=CONFIG['db'])
        cursor = conn.cursor()

        # 先删除预约表中的相关记录
        cursor.execute('''
            DELETE FROM bookings
            WHERE venue_id=%s
        ''', (id,))

        # 然后删除场馆信息
        cursor.execute('''
            DELETE FROM venues
            WHERE id=%s
        ''', (id,))

        conn.commit()
    except Exception as e:
        print('delete error!')
        print(e)
        res = False
    finally:
        if conn:
            conn.close()
        return res



def get_all_venue_info() -> list:
    """
    获取所有场馆信息
    :return: 场馆信息列表
    """
    try:
        conn = pymysql.connect(host=CONFIG['host'], user=CONFIG['user'], password=CONFIG['pwd'], database=CONFIG['db'])
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, name, location, capacity, open_time, close_time
            FROM venues
        ''')
        res = cursor.fetchall()
        # 去除末尾空格并转换为列表格式
        res = [tuple(map(remove_blank, i)) for i in res]
    except Exception as e:
        print('get_all_venue_info error!')
        print(e)
        res = []
    finally:
        if conn:
            conn.close()
        return res

def book_venue(vid: str, uid: str, booking_date: str, start_time: str, end_time: str) -> bool:
    """
    预定场馆
    :param vid: 场馆ID
    :param uid: 用户ID
    :param booking_date: 预约日期
    :param start_time: 开始时间
    :param end_time: 结束时间
    :return: 预定结果布尔值
    """
    try:
        conn = pymysql.connect(host=CONFIG['host'], user=CONFIG['user'], password=CONFIG['pwd'], database=CONFIG['db'])
        cursor = conn.cursor()

        # 将输入的日期和时间转换为datetime对象
        booking_date_obj = datetime.strptime(booking_date, '%Y-%m-%d').date()
        start_time_obj = datetime.strptime(start_time, '%H:%M').time()
        end_time_obj = datetime.strptime(end_time, '%H:%M').time()
        start_time_delta = timedelta(hours=start_time_obj.hour, minutes=start_time_obj.minute)
        end_time_delta = timedelta(hours=end_time_obj.hour, minutes=end_time_obj.minute)
        current_date = datetime.now().date()

        # 检查预约日期是否超过当日日期
        if booking_date_obj < current_date:
            print('Booking date cannot be in the past.')
            return False

        # 获取场馆的开放时间
        cursor.execute('SELECT open_time, close_time, capacity FROM venues WHERE id=%s', (vid,))
        result = cursor.fetchone()
        if not result:
            print('Venue does not exist.')
            return False

        open_time = result[0]
        close_time = result[1]
        capacity = result[2]

        # 检查场馆是否有剩余容量
        if capacity <= 0:
            print('Venue is fully booked.')
            return False

        # 检查预约时间是否在场馆的开放时间范围内
        if start_time_delta < open_time or end_time_delta > close_time:
            print('Booking time is outside the venue\'s open hours.')
            return False

        # 更新场馆的容量
        cursor.execute('UPDATE venues SET capacity = capacity - 1 WHERE id=%s', (vid,))

        # 在bookings表内新建记录
        cursor.execute('''
            INSERT INTO bookings (user_id, venue_id, booking_date, start_time, end_time, status)
            VALUES (%s, %s, %s, %s, %s, '成功')
        ''', (uid, vid, booking_date_obj, start_time_obj, end_time_obj))

        # 提交事务
        conn.commit()
        res = True

    except Exception as e:
        print('Borrow venue error!')
        print(e)
        res = False

    finally:
        if conn:
            conn.close()

    return res

def cancel_booking(booking_id: int) -> bool:
    """
    取消预约
    :param booking_id: 预约ID
    :return: 取消结果布尔值
    """
    try:
        conn = pymysql.connect(host=CONFIG['host'], user=CONFIG['user'], password=CONFIG['pwd'], database=CONFIG['db'])
        cursor = conn.cursor()

        # 获取该预约记录的信息
        cursor.execute('SELECT venue_id FROM bookings WHERE id=%s', (booking_id,))
        result = cursor.fetchone()
        if not result:
            print('Booking does not exist.')
            return False

        venue_id = result[0]

        # 删除预约记录
        cursor.execute('DELETE FROM bookings WHERE id=%s', (booking_id,))

        # 更新场馆的容量
        cursor.execute('UPDATE venues SET capacity = capacity + 1 WHERE id=%s', (venue_id,))

        conn.commit()
        return True

    except Exception as e:
        print('Cancel booking error!')
        print(e)
        return False

    finally:
        if conn:
            conn.close()

def search_user(search_value: str = '') -> list:
    """
    根据参数搜索用户（用户ID或姓名）
    :param search_value: 搜索参数（用户ID或姓名）
    :return: 匹配用户的详细信息列表
    """
    try:
        # 连接数据库
        conn = pymysql.connect(host=CONFIG['host'], user=CONFIG['user'], password=CONFIG['pwd'], database=CONFIG['db'])
        cursor = conn.cursor()

        # SQL 查询语句
        query = '''
            SELECT id, name, email, phone
            FROM users
        '''
        params = []

        if search_value:
            query += '''
                WHERE id LIKE %s OR name LIKE %s
            '''
            search_param = f"%{search_value}%"
            params.extend([search_param, search_param])

        cursor.execute(query, params)

        # 获取查询结果
        results = cursor.fetchall()
        user_list = [[str(cell) for cell in row] for row in results]

    except Exception as e:
        # 输出错误信息
        print('搜索用户错误！')
        print(e)
        user_list = []

    finally:
        # 关闭数据库连接
        if conn:
            conn.close()

    return user_list

def backup_database(output_file):
    try:
        subprocess.run(
            ["mysqldump", "-h", CONFIG["host"], "-u", CONFIG["user"], f"--password={CONFIG['pwd']}", CONFIG["db"]],
            stdout=open(output_file, "w"),
            check=True
        )
        print("Backup successful!")
    except subprocess.CalledProcessError as e:
        print("Error during backup:", e)

def restore_database(input_file):
    try:
        subprocess.run(
            ["mysql", "-h", CONFIG["host"], "-u", CONFIG["user"], f"--password={CONFIG['pwd']}", CONFIG["db"]],
            stdin=open(input_file, "r"),
            check=True
        )
        print("Restore successful!")
    except subprocess.CalledProcessError as e:
        print("Error during restore:", e)