import sys
import os
from PyQt5.QtWidgets import (QApplication, QWidget, QGridLayout, QGroupBox,
                             QToolButton, QSplitter, QVBoxLayout, QHBoxLayout,
                             QLabel, QTableWidget, QTableWidgetItem, QAbstractItemView,
                             QLineEdit, QFileDialog, QMessageBox, QComboBox)
from PyQt5.QtGui import QIcon, QFont
from PyQt5.QtCore import Qt, QSize
import func
import user_information
import venue_information

class AdministratorPage(QWidget):
    def __init__(self, info):
        super().__init__()
        self.info = info
        self.focus = 0
        self.initUI()

    def initUI(self):
        # 标题栏
        self.titleBar = QWidget()
        self.titleBar.setFixedSize(1250, 50)
        self.setTitleBar()

        # 分割
        self.body = QSplitter(Qt.Vertical, self)
        self.setLeftMenu()
        self.content = None
        self.setContent()

        self.bodyLayout = QGridLayout()
        self.bodyLayout.addWidget(self.titleBar, 0, 0, 1, 7)
        self.bodyLayout.addWidget(self.body, 1, 0, 7, 7)
        self.setContentsMargins(0, 0, 0, 0)
        self.setLayout(self.bodyLayout)
        self.setFixedSize(1280, 720)
        self.setMyStyle()

    # 设置标题栏
    def setTitleBar(self):
        self.title = QLabel()
        self.title.setText('场馆预约管理系统-----管理员界面')
        self.title.setFixedHeight(30)

        self.account = QToolButton()
        self.account.setText('管理员用户：' + self.info['id'])
        self.account.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.account.setFixedHeight(30)
        self.account.setEnabled(False)

        self.out = QToolButton()
        self.out.setText('退出')
        self.out.setFixedHeight(30)

        titleLayout = QHBoxLayout()
        titleLayout.addSpacing(100)
        titleLayout.addWidget(self.title)
        titleLayout.addWidget(self.account)
        titleLayout.addWidget(self.out)
        self.titleBar.setLayout(titleLayout)

    def setLeftMenu(self):
        # 场馆管理
        self.venueManage = QToolButton()
        self.venueManage.setText('场馆管理')
        self.venueManage.setFixedSize(160, 50)
        self.venueManage.clicked.connect(
            lambda: self.switch(0, self.venueManage))
        self.venueManage.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)

        # 用户管理
        self.userManage = QToolButton()
        self.userManage.setText('用户管理')
        self.userManage.setFixedSize(160, 50)
        self.userManage.clicked.connect(lambda: self.switch(1, self.userManage))
        self.userManage.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)

        # 预约管理
        self.bookingManage = QToolButton()
        self.bookingManage.setText('预约管理')
        self.bookingManage.setFixedSize(160, 50)
        self.bookingManage.clicked.connect(lambda: self.switch(2, self.bookingManage))
        self.bookingManage.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)

        # 数据库备份
        self.backupButton = QToolButton()
        self.backupButton.setText('备份数据库')
        self.backupButton.setFixedSize(160, 50)
        self.backupButton.clicked.connect(self.backup_database)
        self.backupButton.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)

        # 数据库恢复
        self.restoreButton = QToolButton()
        self.restoreButton.setText('恢复数据库')
        self.restoreButton.setFixedSize(160, 50)
        self.restoreButton.clicked.connect(self.restore_database)
        self.restoreButton.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)

        self.btnList = [self.venueManage, self.userManage, self.bookingManage, self.backupButton, self.restoreButton]

        self.layout = QHBoxLayout()
        self.layout.addStretch()
        self.layout.addWidget(self.venueManage)
        self.layout.addStretch()
        self.layout.addWidget(self.userManage)
        self.layout.addStretch()
        self.layout.addWidget(self.bookingManage)
        self.layout.addStretch()
        self.layout.addWidget(self.backupButton)
        self.layout.addStretch()
        self.layout.addWidget(self.restoreButton)
        self.layout.addStretch()
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)

        self.menu = QGroupBox()
        self.menu.setFixedSize(1250, 50)
        self.menu.setLayout(self.layout)
        self.menu.setContentsMargins(0, 0, 0, 0)
        self.body.addWidget(self.menu)

    def switch(self, index, btn):
        self.focus = index
        for i in self.btnList:
            i.setStyleSheet('''
            *{
                background: white;
            }
            QToolButton:hover{
                background-color: rgba(230, 230, 230, 0.3);
            }
            ''')

        btn.setStyleSheet('''
        QToolButton{
            background-color: rgba(230, 230, 230, 0.7);
        }
        ''')
        self.setContent()

    # 设置右侧信息页
    def setContent(self):
        if self.content is not None:
            self.content.deleteLater()
        if self.focus == 0:
            self.content = VenueManage()
        elif self.focus == 1:
            self.content = UserManage()
        elif self.focus == 2:
            self.content = BookingManage()
        self.body.addWidget(self.content)

    def setMyStyle(self):
        self.setStyleSheet('''
        QWidget{
            background-color: white;
        }
        ''')
        self.titleBar.setStyleSheet('''
        QWidget{
            background-color: rgba(44,44,44,1);
            border:1px solid black;
        }
        ''')
        self.menu.setStyleSheet('''
        QWidget{
            border: 0px;
            border-right: 1px solid rgba(227, 227, 227, 1);
        }
        QToolButton{
            color: rgba(51, 90, 129, 1);
            font-family: 微软雅黑;
            font-size: 25px;
            border-right: 1px solid rgba(227, 227, 227, 1);
        }
        QToolButton:hover{
            background-color: rgba(230, 230, 230, 0.3);
        }
        ''')
        self.title.setStyleSheet('''
        *{
            color: white;
            font-family: 微软雅黑;
            font-size: 25px;
            border: 0px;
        }
        ''')
        self.account.setStyleSheet('''
        *{
            color: white;
            font-weight: 微软雅黑;
            font-size: 25px;
            border: 0px;
        }
        ''')
        self.out.setStyleSheet('''
        QToolButton{
            color: white;
            border:0px;
            font-size: 12px;
        }
        QToolButton:hover{
            color: rgba(11, 145, 255, 1);
        }
        ''')

    def backup_database(self):
        output_file = QFileDialog.getSaveFileName(self, '保存备份', '', 'SQL Files (*.sql)')[0]
        if output_file:
            func.backup_database(output_file)

    def restore_database(self):
        input_file = QFileDialog.getOpenFileName(self, '选择备份文件', '', 'SQL Files (*.sql)')[0]
        if input_file:
            func.restore_database(input_file)



class VenueManage(QGroupBox):
    def __init__(self):
        super().__init__()
        self.venue_list = []
        self.body = QVBoxLayout()
        self.table = None
        self.setTitleBar()
        self.setSearchBar()
        self.searchFunction()

        self.setLayout(self.body)
        self.initUI()

    # 标题栏
    def setTitleBar(self):
        self.title = QLabel()
        self.title.setText('场馆信息管理')
        self.title.setFixedHeight(25)
        titleLayout = QHBoxLayout()
        titleLayout.addStretch()
        titleLayout.addWidget(self.title)
        titleLayout.addStretch()
        self.titleBar = QWidget()
        self.titleBar.setFixedSize(1250, 50)
        self.titleBar.setLayout(titleLayout)
        self.body.addWidget(self.titleBar)

    # 设置搜索框
    def setSearchBar(self):
        self.selectBox = QComboBox()
        self.selectBox.addItems(['场馆ID', '场馆名称', '位置'])
        self.selectBox.setFixedHeight(30)
        self.searchTitle = QLabel()
        self.searchTitle.setText('搜索场馆')
        self.searchInput = QLineEdit()
        self.searchInput.setText('')
        self.searchInput.setClearButtonEnabled(True)
        self.searchInput.setFixedSize(400, 40)
        self.searchButton = QToolButton()
        self.searchButton.setFixedSize(100, 40)
        self.searchButton.setText('搜索')
        self.searchButton.clicked.connect(self.searchFunction)
        self.addNewVenueButton = QToolButton()
        self.addNewVenueButton.setFixedSize(120, 40)
        self.addNewVenueButton.setText('新增场馆')
        self.addNewVenueButton.clicked.connect(self.addNewVenueFunction)
        searchLayout = QHBoxLayout()
        searchLayout.addStretch()
        searchLayout.addWidget(self.selectBox)
        searchLayout.addWidget(self.searchTitle)
        searchLayout.addWidget(self.searchInput)
        searchLayout.addWidget(self.searchButton)
        searchLayout.addWidget(self.addNewVenueButton)
        searchLayout.addStretch()
        self.searchWidget = QWidget()
        self.searchWidget.setLayout(searchLayout)
        self.body.addWidget(self.searchWidget)

    # 搜索方法
    def searchFunction(self):
        convert = {'场馆ID': 'id', '场馆名称': 'name', '位置': 'location'}
        search_value = self.searchInput.text().strip()

        if search_value == '':
            self.venue_list = func.get_all_venue_info()  # 获取所有场馆信息
        else:
            self.venue_list = func.get_venue_info(search_value)

        if self.venue_list == []:
            print('未找到')
        if self.table is not None:
            self.table.deleteLater()
        self.setTable()

    # 设置表格
    def setTable(self):
        self.table = QTableWidget(1, 7)
        self.table.setContentsMargins(10, 10, 10, 10)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setFocusPolicy(Qt.NoFocus)
        self.table.setColumnWidth(0, 150)
        self.table.setColumnWidth(6, 150)

        self.table.setItem(0, 0, QTableWidgetItem('场馆ID'))
        self.table.setItem(0, 1, QTableWidgetItem('场馆名称'))
        self.table.setItem(0, 2, QTableWidgetItem('位置'))
        self.table.setItem(0, 3, QTableWidgetItem('容量'))
        self.table.setItem(0, 4, QTableWidgetItem('开放时间'))
        self.table.setItem(0, 5, QTableWidgetItem('关闭时间'))
        self.table.setItem(0, 6, QTableWidgetItem('操作'))

        for i in range(7):
            self.table.item(0, i).setTextAlignment(Qt.AlignCenter)
            self.table.item(0, i).setFont(QFont('微软雅黑', 15))

        # 显示场馆详情
        for i in self.venue_list:
            self.insertRow(i)
        self.body.addWidget(self.table)

    # 插入行
    def insertRow(self, val: list):
        itemVID = QTableWidgetItem(val[0])
        itemVID.setTextAlignment(Qt.AlignCenter)

        itemName = QTableWidgetItem(val[1])
        itemName.setTextAlignment(Qt.AlignCenter)

        itemLocation = QTableWidgetItem(val[2])
        itemLocation.setTextAlignment(Qt.AlignCenter)

        itemCapacity = QTableWidgetItem(str(val[3]))
        itemCapacity.setTextAlignment(Qt.AlignCenter)

        itemOpenTime = QTableWidgetItem(str(val[4]))
        itemOpenTime.setTextAlignment(Qt.AlignCenter)

        itemCloseTime = QTableWidgetItem(str(val[5]))
        itemCloseTime.setTextAlignment(Qt.AlignCenter)

        itemModify = QToolButton(self.table)
        itemModify.setFixedSize(75, 25)
        itemModify.setText('修改')
        itemModify.clicked.connect(lambda: self.updateVenueFunction(val[0]))
        itemModify.setStyleSheet('''
        *{
            color: white;
            font-family: 微软雅黑;
            background: rgba(38, 175, 217, 1);
            border: 0;
        }
        ''')
        itemDelete = QToolButton(self.table)
        itemDelete.setFixedSize(75, 25)
        itemDelete.setText('删除')
        itemDelete.clicked.connect(lambda: self.deleteVenueFunction(val[0]))
        itemDelete.setStyleSheet('''
        *{
            color: white;
            font-family: 微软雅黑;
            background: rgba(222, 52, 65, 1);
            border: 0;
        }
        ''')

        itemLayout = QHBoxLayout()
        itemLayout.setContentsMargins(0, 0, 0, 0)
        itemLayout.addWidget(itemModify)
        itemLayout.addWidget(itemDelete)
        itemWidget = QWidget()
        itemWidget.setLayout(itemLayout)

        self.table.insertRow(1)
        self.table.setItem(1, 0, itemVID)
        self.table.setItem(1, 1, itemName)
        self.table.setItem(1, 2, itemLocation)
        self.table.setItem(1, 3, itemCapacity)
        self.table.setItem(1, 4, itemOpenTime)
        self.table.setItem(1, 5, itemCloseTime)
        self.table.setCellWidget(1, 6, itemWidget)

    def updateVenueFunction(self, vid: str):
        venue_info_list = func.get_venue_info(vid)
        venue_info = venue_info_list[0]
        venue_info_dict = {
            'id': venue_info[0],
            'name': venue_info[1],
            'location': venue_info[2],
            'capacity': str(venue_info[3]),
            'open_time': str(venue_info[4]),
            'close_time': str(venue_info[5])
        }
        if venue_info is None:
            return
        self.updateVenueDialog = venue_information.VenueInfo(venue_info_dict)
        self.updateVenueDialog.after_close.connect(self.updateVenue)
        self.updateVenueDialog.show()

    def updateVenue(self, venue_info: dict):
        ans = func.update_venue(venue_info)
        if ans:
            self.searchFunction()

    def addNewVenueFunction(self):
        self.newVenueDialog = venue_information.VenueInfo()
        self.newVenueDialog.show()
        self.newVenueDialog.after_close.connect(self.addNewVenue)

    def addNewVenue(self, venue_info: dict):
        ans = func.new_venue(venue_info)
        if ans:
            self.searchFunction()

    def deleteVenueFunction(self, vid: str):
        msgBox = QMessageBox(QMessageBox.Warning, "警告!", '您将会永久删除此场馆及相关信息!',
                             QMessageBox.NoButton, self)
        msgBox.addButton("确认", QMessageBox.AcceptRole)
        msgBox.addButton("取消", QMessageBox.RejectRole)
        if msgBox.exec_() == QMessageBox.AcceptRole:
            ans = func.delete_venue(vid)
            if ans:
                self.searchFunction()

    def errorBox(self, mes: str):
        msgBox = QMessageBox(
            QMessageBox.Warning,
            "错误!",
            mes,
            QMessageBox.NoButton,
            self
        )
        msgBox.addButton("确认", QMessageBox.AcceptRole)
        msgBox.exec_()

    def initUI(self):
        self.setFixedSize(1270, 600)
        self.setStyleSheet('''
        *{
            background-color: white;
            border:0px;
        }
        ''')
        self.titleBar.setStyleSheet('''
        QWidget {
            border:0;
            background-color: rgba(216, 216, 216, 1);
            color: rgba(113, 118, 121, 1);
        }
        QLabel{
            font-size: 25px;
            font-family: 微软雅黑;
        }
        ''')
        self.searchTitle.setStyleSheet('''
            QLabel{
                font-size:25px;
                color: black;
                font-family: 微软雅黑;
            }
        ''')
        self.searchInput.setStyleSheet('''
            QLineEdit{
                border: 1px solid rgba(201, 201, 201, 1);
                color: rgba(120, 120, 120, 1)
            }
        ''')
        self.searchButton.setStyleSheet('''
            QToolButton{
                background-color:rgba(52, 118, 176, 1);
                color: white;
                font-size: 25px;
                font-family: 微软雅黑;
            }
        ''')
        self.addNewVenueButton.setStyleSheet('''
            QToolButton{
                background-color:rgba(52, 118, 176, 1);
                color: white;
                font-size: 25px;
                font-family: 微软雅黑;
            }
        ''')
        self.selectBox.setStyleSheet('''
        *{
            border: 0px;
        }
        QComboBox{
            border: 1px solid rgba(201, 201, 201, 1);
        }
        ''')


class UserManage(QWidget):
    def __init__(self):
        super().__init__()
        self.user_list = []
        self.body = QVBoxLayout()
        self.table = None
        self.setTitleBar()
        self.setSearchBar()
        self.searchFunction()

        self.setLayout(self.body)
        self.initUI()

    # 标题栏
    def setTitleBar(self):
        self.title = QLabel()
        self.title.setText('用户信息管理')
        self.title.setFixedHeight(25)
        titleLayout = QHBoxLayout()
        titleLayout.addStretch()
        titleLayout.addWidget(self.title)
        titleLayout.addStretch()
        self.titleBar = QWidget()
        self.titleBar.setFixedSize(1270, 50)
        self.titleBar.setLayout(titleLayout)
        self.body.addWidget(self.titleBar)

    # 设置搜索框
    def setSearchBar(self):
        self.searchTitle = QLabel()
        self.searchTitle.setText('搜索用户')
        self.searchInput = QLineEdit()
        self.searchInput.setText('ID/姓名')
        self.searchInput.setClearButtonEnabled(True)
        self.searchInput.setFixedSize(400, 40)
        self.searchButton = QToolButton()
        self.searchButton.setFixedSize(100, 40)
        self.searchButton.setText('搜索')
        self.searchButton.clicked.connect(self.searchFunction)

        searchLayout = QHBoxLayout()
        searchLayout.addStretch()
        searchLayout.addWidget(self.searchTitle)
        searchLayout.addWidget(self.searchInput)
        searchLayout.addWidget(self.searchButton)
        searchLayout.addStretch()

        self.searchWidget = QWidget()
        self.searchWidget.setLayout(searchLayout)
        self.body.addWidget(self.searchWidget)

    # 搜索方法
    def searchFunction(self):
        search_value = self.searchInput.text()
        if search_value == 'ID/姓名':
            search_value = ''
        self.user_list = func.search_user(search_value)
        if self.user_list == []:
            print('未找到')
        if self.table is not None:
            self.table.deleteLater()
        self.setTable()

    # 设置表格
    def setTable(self):
        self.table = QTableWidget(1, 5)
        self.table.setContentsMargins(10, 10, 10, 10)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setFocusPolicy(Qt.NoFocus)

        self.table.setColumnWidth(2, 150)
        self.table.setColumnWidth(3, 175)
        self.table.setColumnWidth(4, 175)

        self.table.setItem(0, 0, QTableWidgetItem('用户ID'))
        self.table.setItem(0, 1, QTableWidgetItem('姓名'))
        self.table.setItem(0, 2, QTableWidgetItem('邮箱'))
        self.table.setItem(0, 3, QTableWidgetItem('电话'))
        self.table.setItem(0, 4, QTableWidgetItem('操作'))

        for i in range(5):
            self.table.item(0, i).setTextAlignment(Qt.AlignCenter)
            self.table.item(0, i).setFont(QFont('微软雅黑', 15))

        # 显示用户详情
        for i in self.user_list:
            self.insertRow(i)
        self.body.addWidget(self.table)

    # 插入行
    def insertRow(self, val: list):
        itemUID = QTableWidgetItem(val[0])
        itemUID.setTextAlignment(Qt.AlignCenter)

        itemName = QTableWidgetItem(val[1])
        itemName.setTextAlignment(Qt.AlignCenter)

        itemEmail = QTableWidgetItem(val[2])
        itemEmail.setTextAlignment(Qt.AlignCenter)

        itemPhone = QTableWidgetItem(val[3])
        itemPhone.setTextAlignment(Qt.AlignCenter)

        itemModify = QToolButton(self.table)
        itemModify.setFixedSize(50, 25)
        itemModify.setText('修改')
        itemModify.clicked.connect(lambda: self.updateUserFunction(val[0]))
        itemModify.setStyleSheet('''
        *{
            color: white;
            font-family: 微软雅黑;
            background: rgba(38, 175, 217, 1);
            border: 0;
        }
        ''')
        itemDelete = QToolButton(self.table)
        itemDelete.setFixedSize(50, 25)
        itemDelete.setText('删除')
        itemDelete.clicked.connect(lambda: self.deleteUserFunction(val[0]))
        itemDelete.setStyleSheet('''
        *{
            color: white;
            font-family: 微软雅黑;
            background: rgba(222, 52, 65, 1);
            border: 0;
        }
        ''')

        itemLayout = QHBoxLayout()
        itemLayout.setContentsMargins(0, 0, 0, 0)
        itemLayout.addWidget(itemModify)
        itemLayout.addWidget(itemDelete)
        itemWidget = QWidget()
        itemWidget.setLayout(itemLayout)

        self.table.insertRow(1)
        self.table.setItem(1, 0, itemUID)
        self.table.setItem(1, 1, itemName)
        self.table.setItem(1, 2, itemEmail)
        self.table.setItem(1, 3, itemPhone)
        self.table.setCellWidget(1, 4, itemWidget)

    def updateUserFunction(self, uid: str):
        user_info = func.get_users_info(uid)
        if user_info is None:
            return
        self.updateUserDialog = user_information.UserInfo(user_info)
        self.updateUserDialog.after_close.connect(self.updateUser)
        self.updateUserDialog.show()

    def updateUser(self, user_info: dict):
        ans = func.update_users(user_info)
        if ans:
            self.searchFunction()

    def deleteUserFunction(self, uid: str):
        msgBox = QMessageBox(QMessageBox.Warning, "警告!", '您将会永久删除此用户及相关信息!',
                             QMessageBox.NoButton, self)
        msgBox.addButton("确认", QMessageBox.AcceptRole)
        msgBox.addButton("取消", QMessageBox.RejectRole)
        if msgBox.exec_() == QMessageBox.AcceptRole:
            ans = func.delete_users(uid)
            if ans:
                self.searchFunction()

    def errorBox(self, mes: str):
        msgBox = QMessageBox(
            QMessageBox.Warning,
            "错误!",
            mes,
            QMessageBox.NoButton,
            self
        )
        msgBox.addButton("确认", QMessageBox.AcceptRole)
        msgBox.exec_()

    def initUI(self):
        self.setFixedSize(1270, 600)
        self.setStyleSheet('''
        *{
            background-color: white;
            border:0px;
        }
        ''')
        self.titleBar.setStyleSheet('''
        QWidget {
            border:0;
            background-color: rgba(216, 216, 216, 1);
            color: rgba(113, 118, 121, 1);
        }
        QLabel{
            font-size: 25px;
            font-family: 微软雅黑;
        }
        ''')
        self.searchTitle.setStyleSheet('''
            QLabel{
                font-size:25px;
                color: black;
                font-family: 微软雅黑;
            }
        ''')
        self.searchInput.setStyleSheet('''
            QLineEdit{
                border: 1px solid rgba(201, 201, 201, 1);
                color: rgba(120, 120, 120, 1)
            }
        ''')
        self.searchButton.setStyleSheet('''
            QToolButton{
                background-color:rgba(52, 118, 176, 1);
                color: white;
                font-size: 25px;
                font-family: 微软雅黑;
            }
        ''')


class BookingManage(QWidget):
    def __init__(self):
        super().__init__()
        self.body = QVBoxLayout()
        self.booking_list = []
        self.table = None
        self.setTitleBar()
        self.setSearchBar()
        self.searchFunction()

        self.setLayout(self.body)
        self.initUI()

    def setTitleBar(self):
        self.title = QLabel()
        self.title.setText('预约信息管理')
        self.title.setFixedHeight(25)
        titleLayout = QHBoxLayout()
        titleLayout.addStretch()
        titleLayout.addWidget(self.title)
        titleLayout.addStretch()
        self.titleBar = QWidget()
        self.titleBar.setFixedSize(1270, 50)
        self.titleBar.setLayout(titleLayout)
        self.body.addWidget(self.titleBar)

    def setSearchBar(self):
        self.searchTitle = QLabel()
        self.searchTitle.setText('搜索用户或场馆')
        self.searchInput = QLineEdit()
        self.searchInput.setPlaceholderText('ID/姓名/场馆名')
        self.searchInput.setClearButtonEnabled(True)
        self.searchInput.setFixedSize(450, 40)
        self.searchButton = QToolButton()
        self.searchButton.setFixedSize(120, 40)
        self.searchButton.setText('搜索')
        self.searchButton.clicked.connect(self.searchFunction)

        searchLayout = QHBoxLayout()
        searchLayout.addStretch()
        searchLayout.addWidget(self.searchTitle)
        searchLayout.addWidget(self.searchInput)
        searchLayout.addWidget(self.searchButton)
        searchLayout.addStretch()

        self.searchWidget = QWidget()
        self.searchWidget.setLayout(searchLayout)
        self.body.addWidget(self.searchWidget)

    def searchFunction(self):
        try:
            self.booking_list = func.get_booking_history(self.searchInput.text())

            if not self.booking_list:
                QMessageBox.information(self, "信息", "未找到相关记录", QMessageBox.Ok)
                return

            if self.table is not None:
                self.table.deleteLater()

            self.setTable()
        except Exception as ex:
            print(f"Search function error: {ex}")
            QMessageBox.critical(self, "错误", f"搜索过程中出现错误: {ex}", QMessageBox.Ok)

    def setTable(self):
        try:
            self.table = QTableWidget(1, 8)
            self.table.setContentsMargins(10, 10, 10, 10)
            self.table.setFixedHeight(500)
            self.table.verticalHeader().setVisible(False)
            self.table.horizontalHeader().setVisible(False)
            self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
            self.table.setFocusPolicy(Qt.NoFocus)
            self.table.setColumnWidth(0, 150)
            self.table.setColumnWidth(1, 150)
            self.table.setColumnWidth(2, 200)
            self.table.setColumnWidth(3, 150)
            self.table.setColumnWidth(4, 150)
            self.table.setColumnWidth(5, 100)
            self.table.setColumnWidth(6, 100)
            self.table.setColumnWidth(7, 100)

            self.table.setItem(0, 0, QTableWidgetItem('预约ID'))
            self.table.setItem(0, 1, QTableWidgetItem('用户ID'))
            self.table.setItem(0, 2, QTableWidgetItem('场馆ID'))
            self.table.setItem(0, 3, QTableWidgetItem('场馆名称'))
            self.table.setItem(0, 4, QTableWidgetItem('预约日期'))
            self.table.setItem(0, 5, QTableWidgetItem('开始时间'))
            self.table.setItem(0, 6, QTableWidgetItem('结束时间'))
            self.table.setItem(0, 7, QTableWidgetItem('操作'))

            for i in range(8):
                self.table.item(0, i).setTextAlignment(Qt.AlignCenter)
                self.table.item(0, i).setFont(QFont('微软雅黑', 15))

            for i in self.booking_list:
                self.insertRow(i)

            self.body.addWidget(self.table)
        except Exception as ex:
            print(f"Set table error: {ex}")
            QMessageBox.critical(self, "错误", f"设置表格过程中出现错误: {ex}", QMessageBox.Ok)

    def insertRow(self, val: list):
        itemID = QTableWidgetItem(str(val[0]))
        itemID.setTextAlignment(Qt.AlignCenter)

        itemUID = QTableWidgetItem(val[1])
        itemUID.setTextAlignment(Qt.AlignCenter)

        itemVID = QTableWidgetItem(val[2])
        itemVID.setTextAlignment(Qt.AlignCenter)

        itemName = QTableWidgetItem(val[3])
        itemName.setTextAlignment(Qt.AlignCenter)

        itemDate = QTableWidgetItem(val[4])
        itemDate.setTextAlignment(Qt.AlignCenter)

        itemStartTime = QTableWidgetItem(val[5])
        itemStartTime.setTextAlignment(Qt.AlignCenter)

        itemEndTime = QTableWidgetItem(val[6])
        itemEndTime.setTextAlignment(Qt.AlignCenter)

        itemOperate = QToolButton(self.table)
        itemOperate.setFixedSize(70, 25)

        if val[7] == '已结束':
            itemOperate.setText('已结束')
            itemOperate.setEnabled(False)
            itemOperate.setStyleSheet('''
            *{
                color: gray;
                font-family: 微软雅黑;
                background: rgba(192, 192, 192, 1);
                border: 0;
                font-size:18px;
            }
            ''')
        else:
            itemOperate.setText('取消')
            itemOperate.clicked.connect(lambda: self.cancelBooking(val[0]))
            itemOperate.setStyleSheet('''
            *{
                color: white;
                font-family: 微软雅黑;
                background: rgba(222, 52, 65, 1);
                border: 0;
                font-size:18px;
            }
            ''')

        itemLayout = QHBoxLayout()
        itemLayout.setContentsMargins(0, 0, 0, 0)
        itemLayout.addWidget(itemOperate)
        itemWidget = QWidget()
        itemWidget.setLayout(itemLayout)

        self.table.insertRow(1)
        self.table.setItem(1, 0, itemID)
        self.table.setItem(1, 1, itemUID)
        self.table.setItem(1, 2, itemVID)
        self.table.setItem(1, 3, itemName)
        self.table.setItem(1, 4, itemDate)
        self.table.setItem(1, 5, itemStartTime)
        self.table.setItem(1, 6, itemEndTime)
        self.table.setCellWidget(1, 7, itemWidget)

    def cancelBooking(self, booking_id: int):
        try:
            result = QMessageBox.question(self, "确认", "你确定要取消这个预约吗?", QMessageBox.Yes | QMessageBox.No)
            if result == QMessageBox.Yes:
                if func.cancel_booking(booking_id):
                    QMessageBox.information(self, "成功", "预约已取消", QMessageBox.Ok)
                    self.searchFunction()
                else:
                    QMessageBox.critical(self, "错误", "取消预约失败", QMessageBox.Ok)
        except Exception as ex:
            print(f"Cancel booking error: {ex}")
            QMessageBox.critical(self, "错误", f"取消预约过程中出现错误: {ex}", QMessageBox.Ok)

    def initUI(self):
        self.setFixedSize(1270, 600)
        self.setStyleSheet('''
        *{
            background-color: white;
            border:0px;
        }
        ''')
        self.titleBar.setStyleSheet('''
        QWidget {
            border:0;
            background-color: rgba(216, 216, 216, 1);
            color: rgba(113, 118, 121, 1);
        }
        QLabel{
            font-size: 25px;
            font-family: 微软雅黑;
        }
        ''')
        self.searchWidget.setStyleSheet('''
            QToolButton{
                background-color:rgba(52, 118, 176, 1);
                color: white;
                font-size: 25px;
                font-family: 微软雅黑;
            }
            QLineEdit{
                border: 1px solid rgba(201, 201, 201, 1);
                color: rgba(120, 120, 120, 1)
            }
            QLabel{
                font-size:25px;
                color: black;
                font-family: 微软雅黑;
            }
        ''')


if __name__ == '__main__':
    app = QApplication(sys.argv)
    user_message = {
        'class': 'admin',
        'id': 'admin'
    }
    ex = AdministratorPage(user_message)
    ex.show()
    sys.exit(app.exec_())
