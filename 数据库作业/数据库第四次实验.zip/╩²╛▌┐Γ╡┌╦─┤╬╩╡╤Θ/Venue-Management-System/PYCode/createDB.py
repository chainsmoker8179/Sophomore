import pymysql

Config = {
    "host": '127.0.0.1',
    "user": 'root',
    "pwd": 'fen386838',
    'db': 'venue'
}


def create_database():
    conn = None
    try:
        conn = pymysql.connect(host=Config['host'], user=Config['user'], password=Config['pwd'])
        print("成功连接到数据库")
        cursor = conn.cursor()
        conn.autocommit(True)
        cursor.execute("CREATE DATABASE IF NOT EXISTS `{}`".format(Config['db']))
        conn.autocommit(False)
        cursor.execute("USE `{}`".format(Config['db']))
        print("成功创建或切换到数据库：{}".format(Config['db']))

        print("开始创建数据表")
        # 创建用户信息表
        cursor.execute("""CREATE TABLE IF NOT EXISTS `users`(
            `id` VARCHAR(70) PRIMARY KEY,
            `name` VARCHAR(70) NOT NULL,
            `email` VARCHAR(50) NOT NULL UNIQUE,
            `password` VARCHAR(20) NOT NULL,
            `phone` VARCHAR(20)
        );
        """)
        # 创建管理员表
        cursor.execute("""CREATE TABLE IF NOT EXISTS `administrator`(
            `id` VARCHAR(10) PRIMARY KEY,
            `password` VARCHAR(70) NOT NULL
        );
        """)
        # 创建场馆信息表
        cursor.execute("""CREATE TABLE IF NOT EXISTS `venues`(
            `id` VARCHAR(20) PRIMARY KEY,
            `name` VARCHAR(20) NOT NULL,
            `location` VARCHAR(100),
            `capacity` INT NOT NULL,
            `open_time` TIME NOT NULL,
            `close_time` TIME NOT NULL
        );
        """)
        # 创建预约表
        cursor.execute("""CREATE TABLE IF NOT EXISTS `bookings`(
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `user_id` VARCHAR(70) NOT NULL,
            `venue_id` VARCHAR(20) NOT NULL,
            `booking_date` DATE NOT NULL,
            `start_time` TIME NOT NULL,
            `end_time` TIME NOT NULL,
            `status` CHAR(10) NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (venue_id) REFERENCES venues(id)
        );
        """)
        # 导入默认管理员账号密码：admin/123456，导入数据库的是加密之后的信息
        cursor.execute("""
        INSERT INTO administrator (id, password) VALUES ('admin', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92')
        ON DUPLICATE KEY UPDATE password=VALUES(password)
        """)
        conn.commit()
        print("成功创建所有数据表")
    except Exception as e:
        print('数据库建立失败，报错信息如下：')
        print(e)
    finally:
        if conn:
            conn.close()


if __name__ == '__main__':
    create_database()
