# 进行并发测试
import threading
import pytest
from func import book_venue
@pytest.fixture
def venue_id():
    return 'V001'

@pytest.fixture
def user_ids():
    return ['1', 'U001', 'U002']

@pytest.fixture
def booking_date():
    return '2024-06-19'

@pytest.fixture
def start_time():
    return '09:00'

@pytest.fixture
def end_time():
    return '12:00'

@pytest.fixture
def num_threads_per_user():
    return 1

def test_booking_concurrently(venue_id, user_ids, booking_date, start_time, end_time, num_threads_per_user):
    def worker(user_id):
        result = book_venue(venue_id, user_id, booking_date, start_time, end_time)
        if result:
            print(f"Booking successful for user {user_id}")
        else:
            print(f"Booking failed for user {user_id}")

    threads = []
    for user_id in user_ids:
        for _ in range(num_threads_per_user):
            thread = threading.Thread(target=worker, args=(user_id,))
            threads.append(thread)
            thread.start()

    for thread in threads:
        thread.join()