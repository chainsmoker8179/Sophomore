import sys
from PyQt5.QtWidgets import (
    QApplication, QVBoxLayout, QLabel, QLineEdit, QToolButton, QGroupBox, QMessageBox)
from PyQt5.QtCore import pyqtSignal
from PyQt5.QtGui import QIcon
import func  # 假设这个模块中有加密函数 encrypt

class UserInfo(QGroupBox):
    '''
    编辑用户信息的界面
    传入{
        'id': str,
        'name': str,
        'email': str,
        'phone': str
    }
    返回{
        'id': str,
        'name': str,
        'password': str,
        'email': str,
        'phone': str
    }
    '''
    after_close = pyqtSignal(dict)

    def __init__(self, user_info: dict):
        super().__init__()
        self.user_info = user_info

        self.title = QLabel()
        self.title.setText('用户信息')

        self.subTitle = QLabel()
        self.subTitle.setText('编辑用户信息')

        # 用户ID输入框
        self.userIDInput = QLineEdit()
        self.userIDInput.setFixedSize(400, 40)
        self.userIDInput.setText(self.user_info['id'])
        self.userIDInput.initText = '请输入用户ID'
        self.userIDInput.setEnabled(False)

        # 用户名输入框
        self.nameInput = QLineEdit()
        self.nameInput.setFixedSize(400, 40)
        self.nameInput.setText(self.user_info['name'])
        self.nameInput.initText = '请输入用户名'
        self.nameInput.setTextMargins(5, 5, 5, 5)
        self.nameInput.mousePressEvent = lambda x: self.inputClick(self.nameInput)

        # 密码
        self.passwordInput = QLineEdit()
        self.passwordInput.setFixedSize(400, 40)
        self.passwordInput.setText('请输入密码')
        self.passwordInput.initText = '请输入密码'
        self.passwordInput.setTextMargins(5, 5, 5, 5)
        self.passwordInput.mousePressEvent = lambda x: self.inputClick(self.passwordInput)

        # 重复密码
        self.repPasswordInput = QLineEdit()
        self.repPasswordInput.setFixedSize(400, 40)
        self.repPasswordInput.setText('请重复输入密码')
        self.repPasswordInput.initText = '请重复输入密码'
        self.repPasswordInput.setTextMargins(5, 5, 5, 5)
        self.repPasswordInput.mousePressEvent = lambda x: self.inputClick(self.repPasswordInput)

        # 邮箱
        self.emailInput = QLineEdit()
        self.emailInput.setFixedSize(400, 40)
        self.emailInput.setText(self.user_info['email'])
        self.emailInput.initText = '请输入邮箱'
        self.emailInput.setTextMargins(5, 5, 5, 5)
        self.emailInput.mousePressEvent = lambda x: self.inputClick(self.emailInput)

        # 电话
        self.phoneInput = QLineEdit()
        self.phoneInput.setFixedSize(400, 40)
        self.phoneInput.setText(self.user_info['phone'])
        self.phoneInput.initText = '请输入电话'
        self.phoneInput.setTextMargins(5, 5, 5, 5)
        self.phoneInput.mousePressEvent = lambda x: self.inputClick(self.phoneInput)

        # 提交
        self.submit = QToolButton()
        self.submit.setText('提交')
        self.submit.setFixedSize(400, 40)
        self.submit.clicked.connect(self.submitFunction)

        # 退出
        self.back = QToolButton()
        self.back.setText('退出')
        self.back.setFixedSize(400, 40)
        self.back.clicked.connect(self.close)

        self.btnList = [
            self.userIDInput,
            self.nameInput,
            self.passwordInput,
            self.repPasswordInput,
            self.emailInput,
            self.phoneInput
        ]

        self.bodyLayout = QVBoxLayout()
        self.bodyLayout.addWidget(self.title)
        self.bodyLayout.addWidget(self.subTitle)
        for i in self.btnList:
            self.bodyLayout.addWidget(i)
        self.bodyLayout.addWidget(self.submit)
        self.bodyLayout.addWidget(self.back)

        self.setLayout(self.bodyLayout)
        self.initUI()

    def inputClick(self, e):
        for i in range(2, 7):
            item = self.bodyLayout.itemAt(i).widget()
            if item.text() == '':
                item.setText(item.initText)
                if item is self.passwordInput or item is self.repPasswordInput:
                    item.setEchoMode(QLineEdit.Normal)

        if e.text() == e.initText:
            e.setText('')
        if e is self.passwordInput or e is self.repPasswordInput:
            e.setEchoMode(QLineEdit.Password)

    def submitFunction(self):
        if not self.phoneInput.text().isalnum():
            self.errorBox('电话输入错误')
            return
        if self.passwordInput.text() != self.passwordInput.initText:
            if self.passwordInput.text() != self.repPasswordInput.text():
                self.errorBox('两次输入密码不一致!')
                return
            self.user_info['password'] = func.encrypt(self.passwordInput.text())
        self.user_info['name'] = self.nameInput.text()
        self.user_info['email'] = self.emailInput.text()
        self.user_info['phone'] = self.phoneInput.text()
        self.close()
        self.after_close.emit(self.user_info)

    def errorBox(self, mes: str):
        msgBox = QMessageBox(
            QMessageBox.Warning,
            "错误!",
            mes,
            QMessageBox.NoButton,
            self
        )
        msgBox.addButton("确认", QMessageBox.AcceptRole)
        msgBox.exec_()

    def initUI(self):
        self.setFixedSize(422, 500)
        self.setWindowTitle('编辑用户信息')
        self.setMyStyle()

    def setMyStyle(self):
        self.setStyleSheet('''
        QWidget{
            background-color: white;
        }
        QLineEdit{
            border:0px;
            border-bottom: 1px solid rgba(229, 229, 229, 1);
            color: grey;
        }
        QToolButton{
            border: 0px;
            background-color:rgba(52, 118, 176, 1);
            color: white;
            font-size: 25px;
            font-family: 微软雅黑;
        }
        QGroupBox{
            border: 1px solid rgba(229, 229, 229, 1);
            border-radius: 5px;
        }
        ''')
        self.title.setStyleSheet('''
        *{
            color: rgba(113, 118, 121, 1);
            font-size: 30px;
            font-family: 微软雅黑;
        }
        ''')
        self.subTitle.setStyleSheet('''
        *{
            color: rgba(184, 184, 184, 1);
        }
        ''')


if __name__ == '__main__':
    user_msg = {
        'id': 'user01',
        'name': '小张',
        'email': 'xiaozhang@qq.com',
        'phone': '12345678901'
    }
    app = QApplication(sys.argv)
    ex = UserInfo(user_msg)
    ex.show()
    sys.exit(app.exec_())
